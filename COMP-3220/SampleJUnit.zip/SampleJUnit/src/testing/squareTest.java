package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class squareTest {

	@Test
	public void test() {
		JUnitTesting test = new JUnitTesting();
		int output = test.square(5);//how did you choose this value?
		assertEquals(25, output);
		
		int output2 = test.square(9);
		assertEquals(81, output2);
	}
}
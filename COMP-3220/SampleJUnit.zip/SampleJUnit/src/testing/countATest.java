package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class countATest {

	@Test
	public void test() {
		JUnitTesting test = new JUnitTesting();
		int output = test.countA("alphabet");
		assertEquals(2, output);
	}
}
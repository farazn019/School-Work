package testing;

public class JUnitTesting {
	
	public int square (int x) {
		return x*x;
	}
	
	public int countA(String word) { //Alphabet
		int count = 0;
		for (int i = 0; i < word.length(); i++) {
			if (word.charAt(i)=='a' || word.charAt(i)=='A')
				count++;
		}
		return count;
	}
	
	public int search(int[] arr, int val) {
		int foundIdx = 0;
		for (int i = 0; i < arr.length ; i++) {
			if (arr[i]==val)
			{
				foundIdx = i;
				break;
			}
		}
		return foundIdx;
	}
	
	public boolean isPassed(int percentage) {
		if(percentage >=50) {
			return true;
		}else {
			return false;
		}
	}
}
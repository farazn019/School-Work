package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class searchTest {

	@Test
	public void testSearch() {
		JUnitTesting test = new JUnitTesting();
		
		int[] arr = {100, 345, 665, 445, 235};
		int output = test.search(arr, 345);
		assertEquals(1, output);
	}
}

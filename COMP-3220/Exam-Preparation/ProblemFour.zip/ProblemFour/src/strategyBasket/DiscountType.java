package strategyBasket;

//This enumerator is DiscountType, and it contains three values: NoDiscount, MoneyOff, and PercentageOff.
public enum DiscountType {
	NoDiscount,
	MoneyOff,
	PercentageOff
}

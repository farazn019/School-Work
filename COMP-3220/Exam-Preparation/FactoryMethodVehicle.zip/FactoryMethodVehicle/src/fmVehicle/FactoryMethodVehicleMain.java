package fmVehicle;

public class FactoryMethodVehicleMain {
	
	public static void main(String[] args) {
		
	}
}
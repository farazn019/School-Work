
public interface Adder {
	int add(int op1, int op2);
}
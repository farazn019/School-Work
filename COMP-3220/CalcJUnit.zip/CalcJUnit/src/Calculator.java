
public class Calculator implements Adder, Subtractor, Divider {

	@Override
	public int subtract(int op1, int op2) {
		if (op1 > op2)
			return op1-op2;
		else
			return op2-op1;
	}

	@Override
	public int add(int op1, int op2) {
		return op1+op2;
	}
	
	@Override
	public int division(int op1, int op2) {
		if (op2==0)
			throw new ArithmeticException();
		return op1/op2;
	}
}

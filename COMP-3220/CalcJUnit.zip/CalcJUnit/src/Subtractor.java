
public interface Subtractor {
	int subtract(int op1, int op2);
}
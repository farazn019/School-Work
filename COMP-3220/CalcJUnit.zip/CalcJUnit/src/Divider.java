
public interface Divider {
	int division(int op1, int op2);
}
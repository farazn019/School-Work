import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

public class TestCalculator {

	Calculator calc;
	
	@BeforeEach
	public void runBeforeEach() {
		this.calc = new Calculator();
		System.out.println("Print before each test method...");
	}
	
	@Test
	public void testAdd() {
		int outA = calc.add(349, 345);
		assertEquals(694, outA);
	}
	
	@Test
	public void testDivision() {
		int outA = calc.division(15, 3);
		assertEquals(5, outA);
		
		Executable executable = () -> calc.division(3,0);
		assertThrows(ArithmeticException.class, executable);
	}
	
	@Test
	public void testSubtract() {
		int outS1 = calc.subtract(500, 345);
		assertEquals(155, outS1);
		int outS2 = calc.subtract(500, 845);
		assertEquals(345, outS2);
	}
	
	@AfterEach
	public void runAfterEach() {
		this.calc = new Calculator();
		System.out.println("Print after each test method....");
		System.out.println("................................");
	}
}

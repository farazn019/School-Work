import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class TestEmployee {

	EmployeeBusinessLogic empBusinessLogic = new EmployeeBusinessLogic();
	EmployeeDetails employee = new EmployeeDetails();
	
	@BeforeAll
	static void runBeforeAll() {
		System.out.println("Before all unit tests...");
	}
	
	@Test
	public void testCalculateYearlySalary() {
		employee.setName("Alice");
		employee.setAge(25);
		employee.setMonthlySalary(8000);
	
		double salary = empBusinessLogic.calculateYearlySalary(employee);
		assertEquals(96000, salary, 0.1);
	}
	
	
	@Test
	public void testCalculateAppriasal() {
		employee.setName("Bob");
	    employee.setAge(25);
	    employee.setMonthlySalary(8000);
	    
	    double appraisal = empBusinessLogic.calculateAppraisal(employee);
	    assertEquals(499.9, appraisal, 0.11);
	}
	
	@AfterAll
	static void runAfterAll() {
		System.out.println("After all unit tests...");
	}
}


class TestMicrowave{
    public static void main(String[] args){
        microwave this_microwave= new microwave();
        this_microwave.setStart();

    }
}